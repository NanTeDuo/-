import sqlite3

def add(id,name,minzu,history,why,inf):
    conn = sqlite3.connect('women.db')
    conn.execute("INSERT INTO womens VALUES(?,?,?,?,?,?)",
                 (id,name,minzu,history,why,inf))
    conn.commit()
    conn.close()


def searchName(data):
    conn = sqlite3.connect('women.db')
    cursor = conn.cursor()
    cursor.execute("""SELECT * FROM womens WHERE name = ?""", [data])
    results = cursor.fetchall()
    cursor.close()
    conn.commit()
    conn.close()
    return results

def searchWhy(data):
    conn = sqlite3.connect('women.db')
    cursor = conn.cursor()
    cursor.execute("""SELECT * FROM womens WHERE why = ?""", [data])
    results = cursor.fetchall()
    cursor.close()
    conn.commit()
    conn.close()
    return results

def searchMinzu(data):
    conn = sqlite3.connect('women.db')
    cursor = conn.cursor()
    cursor.execute("""SELECT * FROM womens WHERE minzy = ?""", [data])
    results = cursor.fetchall()
    cursor.close()
    conn.commit()
    conn.close()
    return results

def searchHistory(data):
    conn = sqlite3.connect('women.db')
    cursor = conn.cursor()
    cursor.execute("""SELECT * FROM womens WHERE history = ?""", [data])
    results = cursor.fetchall()
    cursor.close()
    conn.commit()
    conn.close()
    return results