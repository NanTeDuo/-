
from PyQt5.QtWidgets import QApplication,QMainWindow
import sys
import ui
import random
import tkinter.messagebox
import tkinter as tk
from tkinter import simpledialog
import opda


def popup(data):
    tkinter.messagebox.showinfo("为了啥", data)
    root = tk.Tk()
    root.withdraw()

temp = []
class person:
    def __init__(self):
        self.id = ""
        self.name = ""
        self.minzu = ""
        self.history = ""
        self.why = ""
        self.infs = ""
    def setInfs(self,ids,name,minzu,history,why,infs):
        self.id = ids
        self.name = name
        self.minzu = minzu
        self.history = history
        self.why = why
        self.infs = infs

    def getInfs(self):
        datas = [self.id,self.name,self.minzu,self.history,self.why,self.infs]
        return datas

class Mainwindow(QMainWindow, ui.Ui_MainWindow):
    mulit = []
    def __init__(self):
        super(Mainwindow,self).__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.adds)
        self.pushButton_2.clicked.connect(self.find)
        self.pushButton_3.clicked.connect(self.setRoot)
        self.pushButton_4.clicked.connect(self.setNormal)
        self.pushButton_8.clicked.connect(self.randID)

        self.ce = False

        self.comboBox.currentTextChanged.connect(self.multdisplay)

        self.lineEdit_5.setText(str(random.randint(11111,99999)))
        self.token = "admin"
        self.useraccess = "root"
        self.useraccess = "root"
        self.accessControl(self.useraccess)
        self.muli = []

    def multdisplay(self):
        if self.ce == True:
          #  print(int(self.comboBox.currentText()))
            current = self.muli[int(self.comboBox.currentText())-1]
            data = current.getInfs()
            self.lineEdit_8.setText(str(data[0]))
            self.lineEdit_7.setText(str(data[1]))
            self.lineEdit_9.setText(str(data[2]))
            self.lineEdit_6.setText(str(data[3]))
            self.lineEdit_10.setText(str(data[4]))
            self.textEdit_2.setText(str(data[5]))

    def dellist(self):
        self.ce = False
        self.comboBox.clear()

    def find(self):
        self.dellist()
        try:
            data = ""
            if self.comboBox_2.currentText() == "姓名":
                data = opda.searchName(self.lineEdit_7.text())
            elif self.comboBox_2.currentText() == "民族":
                data = opda.searchMinzu(self.lineEdit_9.text())
            elif self.comboBox_2.currentText() == "感情史":
                data = opda.searchHistory(self.lineEdit_6.text())
            elif self.comboBox_2.currentText() == "原因":
                data = opda.searchWhy(self.lineEdit_10.text())

            if len(data) == 0:
                popup("未找到")
            elif len(data) == 1:
                data = data[0]
                self.lineEdit_8.setText(str(data[0]))
                self.lineEdit_7.setText(str(data[1]))
                self.lineEdit_9.setText(str(data[2]))
                self.lineEdit_6.setText(str(data[3]))
                self.lineEdit_10.setText(str(data[4]))
                self.textEdit_2.setText(str(data[5]))
                popup("找到1项")
            else:
                count = 1
                self.muli = []
                for a in data:
                    current = a
                    temp = []
                    ap = person()
                    ap.setInfs(str(current[0]),str(current[1]),str(current[2]),str(current[3]),str(current[4]),str(current[5]))
                    self.muli.append(ap)
                    self.comboBox.addItem(str(count))
                    count +=1
                self.ce = True
                popup("找到" + str(len(data)) + "项目")
                self.multdisplay()



        except:
            popup("Error")

    def randID(self):
        self.lineEdit_5.setText(str(random.randint(1,999999)))

    def adds(self):
        try:
            opda.add(int(self.lineEdit_5.text()),self.lineEdit.text(),self.lineEdit_2.text(),self.lineEdit_3.text(),self.lineEdit_4.text(),self.textEdit.toPlainText())
            popup("添加成功")
            self.randID()
        except:
            popup("Error")

    def setRoot(self):
        text = simpledialog.askstring("Input Box", "Enter your token: ")
        if text == self.token:
            self.useraccess = "root"
            self.accessControl(self.useraccess)
            self.label_13.setText("当前为:管理员")
            popup("成功")
        else:
            popup("错误的密码")
        root = tk.Tk()
        root.withdraw()
    def setNormal(self):
        self.useraccess = "normal"
        self.accessControl(self.useraccess)
        self.label_13.setText("当前为:访客")


    def accessControl(self,mode):
        if mode == "root":
            self.groupBox_2.setEnabled(True)
        else:
            self.groupBox_2.setEnabled(False)


    def functions(self):
        ap = person()
        ap.setInfs(self.lineEdit_5.text(),self.lineEdit.text(),self.lineEdit_2.text(),self.lineEdit_3.text(),self.lineEdit_4.text(),self.textEdit.toPlainText())
        ap.getInfs()



def run():
    app = QApplication(sys.argv)
    mainWindow = Mainwindow()
    mainWindow.show()
    sys.exit(app.exec_())
run()

